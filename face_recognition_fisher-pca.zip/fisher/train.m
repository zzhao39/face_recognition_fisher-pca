function [ weights_of_trained ] = train( A, V )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
weights_of_trained=[];
for idx=1:size(A,2)
    weight=V\A(:,idx);
    weights_of_trained=[weights_of_trained, weight];
end

end

