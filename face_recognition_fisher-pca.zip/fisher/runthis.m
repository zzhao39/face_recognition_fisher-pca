clear;
clc;

%First we read all the training images.
[im, person, number, subset] =readFaceImages('faces');

%Convert each [m x n] image matrix into [(m x n) x 1] image vector.(Flatten image matrix to vector).
%Find average_face_vector, sum(all image vectors)/number(images).
[m,n] = size(cell2mat(im(1)));
imagesum=single(zeros(m*n,1));
nfiles = length(im);  
for i=1:nfiles
    currentimage = cell2mat(im(i));
    [m,n] = size(currentimage);
    imv=reshape(currentimage,[m*n,1]);
    ImagesVector{i} = imv;
    imagesum=imagesum+imv;
end

mean_face=imagesum/nfiles;

%Subtract average_face_vector from every image vector.
%Stack all (image_vectors???average_face_vector) in matrix forming A = [(m x n) x i] matrix (where i = number of images).
A=[];
for i=1:nfiles
    A=[A, cell2mat(ImagesVector(i))-mean_face];
end

%Then we will pre-multiply the eigenvectors of transpose(A)*A with A to get eigenvectors of A*transpose(A). ? (Proof is given in paper)
C=transpose(A)*A;

%Choose best k eigenvectors such that k << i.
k=31;
Class_number=10;
Class_population=7+19;

[V,D]=eigs(double(C),k);
V=A*V;

%train the subset one images
subsetone=find(subset==1 | subset==5);
A_train=A(:,subsetone);

%Find weights of each image and store it.
weights_of_trained=train(A_train,V);

mean_of_all = mean(weights_of_trained,2); % Total mean in eigenspace
mean_of_class = zeros(k,Class_number); 
Sw = zeros(k,k); % Initialization os Within Scatter Matrix
Sb = zeros(k,k); % Initialization of Between Scatter Matrix

for i = 1 : Class_number
    mean_of_class(:,i) = mean( ( weights_of_trained(:,((i-1)*Class_population+1):i*Class_population) ), 2 )';    
    
    S  = zeros(k,k); 
    for j = ( (i-1)*Class_population+1 ) : ( i*Class_population )
        S = S + (weights_of_trained(:,j)-mean_of_class(:,i))     *      (weights_of_trained(:,j)-mean_of_class(:,i))';
    end
    
    Sw = Sw + S; % Within Scatter Matrix
    Sb = Sb + (mean_of_class(:,i)-mean_of_all) * (mean_of_class(:,i)-mean_of_all)'; % Between Scatter Matrix
end

%maximise the Between Scatter Matrix
%minimize the within Scatter Matrix
[vector, val] = eig(Sb,Sw);
vectorflip = fliplr(vector);
%largest (C-1) eigen vectors 
fisherv=vectorflip(:,1:Class_number-1); 

projectedfisher= fisherv\weights_of_trained;

%evaluate on all subsets
for id=1:5
    subseteva=find(subset==id);
    testA=A(:,subseteva);
    weights_of_test=train(testA,V);
    projectedtest = fisherv\weights_of_test;
    error=zeros(1,size(projectedtest,2));
    person_pred=zeros(1,size(projectedtest,2));
    for i=1:size(projectedtest,2)
        err=zeros(1,Class_number*Class_population);
        for j=1:Class_number*Class_population
            err(j)=norm( projectedtest(:,i)-projectedfisher(:,j));
        end
        [temp1,temp2] = min(err);
        error(i)=temp1;
        person_pred(i)=person(subsetone(temp2));
        %person_pred(i)=ceil(temp2/7.0);
    end 
    
    groundtruth=person(subseteva);
    error=size(find(person_pred-groundtruth),2)/size(groundtruth,2);
    disp(['error for subset ', int2str(id),' is ', num2str(error*100),'%']);
    
    figure;
    x=1:1:size(subseteva,2);
    plot(x,person_pred,'b',x,person(subseteva),'r')
    string=int2str(id);
    title(strcat('person recognation for subset ', string))
    xlabel('number of test images')
    ylabel('error rates')
end
