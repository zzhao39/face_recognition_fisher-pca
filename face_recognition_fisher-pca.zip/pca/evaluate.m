function [ person1, error1, person2, error2] = evaluate( iter, A, V1, V2, weights_of_trained1, weights_of_trained2, mean_face, subsetone, person)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
eigsize1=size(weights_of_trained1,2);
eigsize2=size(weights_of_trained2,2);
testsize=size(A,2);
error1=zeros(1,testsize);
error2=zeros(1,testsize);
person1=zeros(1,testsize);
person2=zeros(1,testsize);
for idx=1:testsize
    weight1=V1\A(:,idx);
    weight2=V2\A(:,idx);
    if idx==1
        assignin('base',strcat('reconstruct',int2str(iter)),reshape(double(V2*weight2+mean_face),[50,50]));
    end
    err1=zeros(1,eigsize1);
    err2=zeros(1,eigsize2);
    for id=1:eigsize1
        err1(id)=norm(weights_of_trained1(:,id)-weight1);
    end
    for id=1:eigsize2
        err2(id)=norm(weights_of_trained2(:,id)-weight2);
    end
    assignin('base','err1',err1);
    assignin('base','err2',err2);
    [temp1,temp2] = min(err1);
    assignin('base','temp1',temp1);
    assignin('base','temp2',temp2);
    error1(idx)=temp1;
    person1(idx)=person(subsetone(temp2));
    [temp1,temp2] = min(err2);
    error2(idx)=temp1;
    person2(idx)=person(subsetone(temp2));
end
end 